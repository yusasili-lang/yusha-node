/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Upload, 
  Download, 
  File, 
  LogOut, 
  Lock, 
  User, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  HardDrive,
  Eye,
  EyeOff,
  Volume2,
  VolumeX
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FileInfo {
  name: string;
  size: number;
  createdAt: string;
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [files, setFiles] = useState<FileInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const keySoundRef = useRef<HTMLAudioElement | null>(null);

  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isClicking, setIsClicking] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      
      const target = e.target as HTMLElement;
      const isClickable = target.closest('button, a, input, select, textarea, [role="button"]');
      setIsHovering(!!isClickable);
    };

    const handleMouseDown = () => {
      setIsClicking(true);
      playClickSound();
    };

    const handleMouseUp = () => {
      setIsClicking(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isSoundEnabled]);

  const playClickSound = () => {
    if (!isSoundEnabled) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const audioCtx = audioContextRef.current;
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(800, audioCtx.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.1);

      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1);
    } catch (err) {
      console.error('Click sound error:', err);
    }
  };

  useEffect(() => {
    keySoundRef.current = new Audio('https://www.soundjay.com/communication/sounds/typewriter-key-1.mp3');
    keySoundRef.current.load();
  }, []);

  const playKeySound = () => {
    if (!isSoundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(150, audioCtx.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(40, audioCtx.currentTime + 0.1);

      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1);
    } catch (e) {
      console.error('Web Audio failed:', e);
    }
  };

  const playSuccessSound = () => {
    if (!isSoundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playNote = (freq: number, start: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime + start);
        gain.gain.setValueAtTime(0, audioCtx.currentTime + start);
        gain.gain.linearRampToValueAtTime(0.1, audioCtx.currentTime + start + 0.05);
        gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + start + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(audioCtx.currentTime + start);
        osc.stop(audioCtx.currentTime + start + duration);
      };
      playNote(523.25, 0, 0.2); // C5
      playNote(659.25, 0.15, 0.2); // E5
      playNote(783.99, 0.3, 0.4); // G5
    } catch (e) {
      console.error('Web Audio failed:', e);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch('/api/auth-check');
      const data = await res.json();
      setIsAuthenticated(data.authenticated);
      if (data.authenticated) {
        fetchFiles();
      }
    } catch (err) {
      setIsAuthenticated(false);
    }
  };

  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/files');
      if (res.ok) {
        const data = await res.json();
        setFiles(data);
      }
    } catch (err) {
      console.error('Failed to fetch files', err);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      if (res.ok) {
        playSuccessSound();
        setIsAuthenticated(true);
        fetchFiles();
      } else {
        setError('Kullanıcı adı veya şifre hatalı!');
      }
    } catch (err) {
      setError('Bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/logout', { method: 'POST' });
    setIsAuthenticated(false);
    setFiles([]);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      if (res.ok) {
        fetchFiles();
      } else {
        alert('Yükleme başarısız!');
      }
    } catch (err) {
      alert('Yükleme sırasında bir hata oluştu.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDownload = (filename: string) => {
    window.open(`/api/download/${filename}`, '_blank');
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center">
        <div 
          className={`custom-cursor ${isClicking ? 'clicking' : ''} ${isHovering ? 'hovering' : ''}`}
          style={{ left: `${mousePos.x}px`, top: `${mousePos.y}px` }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path d="M0,0 L0,18 L5,13 L8,20 L11,19 L8,12 L14,12 Z" />
          </svg>
        </div>
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 font-sans selection:bg-emerald-500/30">
      <div 
        className={`custom-cursor ${isClicking ? 'clicking' : ''} ${isHovering ? 'hovering' : ''}`}
        style={{ left: `${mousePos.x}px`, top: `${mousePos.y}px` }}
      >
        <svg width="18" height="18" viewBox="0 0 24 24">
          <path d="M0,0 L0,18 L5,13 L8,20 L11,19 L8,12 L14,12 Z" />
        </svg>
      </div>

      <button
        onClick={() => setIsSoundEnabled(!isSoundEnabled)}
        className="fixed top-4 right-4 z-50 p-2 bg-neutral-900/80 border border-neutral-800 rounded-lg text-neutral-400 hover:text-white transition-all active:scale-95 backdrop-blur-sm"
        title={isSoundEnabled ? "Sesi Kapat" : "Sesi Aç"}
      >
        {isSoundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
      </button>

      <AnimatePresence mode="wait">
        {!isAuthenticated ? (
          <motion.div
            key="login"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="min-h-screen flex items-center justify-center p-4"
          >
            <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-8 shadow-2xl">
              <div className="flex flex-col items-center mb-8">
                <div className="w-full h-40 mb-6 rounded-2xl overflow-hidden border border-neutral-800 shadow-xl">
                  <img 
                    src="https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExNzFmOWpndjB2ODFiczZsYmpubzg4OGR5YXF6cnI2a3M5YnNnemxzciZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/ispEc1253326c/giphy.gif" 
                    alt="Aesthetic GIF" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex items-center gap-4 mb-2">
                  <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
                    <Lock className="w-6 h-6 text-emerald-500" />
                  </div>
                  <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                    yushA Upload
                    <svg width="20" height="14" viewBox="0 0 1200 800" className="rounded-sm shadow-sm">
                      <rect width="1200" height="800" fill="#e30a17"/>
                      <circle cx="425" cy="400" r="200" fill="#fff"/>
                      <circle cx="475" cy="400" r="160" fill="#e30a17"/>
                      <polygon points="583.3,400 708.4,440.6 660.6,309.4 660.6,490.6 708.4,359.4" fill="#fff" transform="translate(100, 0)"/>
                    </svg>
                  </h1>
                </div>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-1.5 ml-1">
                    Kullanıcı Adı
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => {
                        setUsername(e.target.value);
                        playKeySound();
                      }}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-emerald-500/50 transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-1.5 ml-1">
                    Şifre
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        playKeySound();
                      }}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl py-3 pl-10 pr-12 focus:outline-none focus:border-emerald-500/50 transition-colors"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-neutral-500 hover:text-neutral-300 transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 p-3 rounded-xl border border-red-400/20"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {error}
                  </motion.div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 rounded-xl transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Giriş Yap'}
                </button>
              </form>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-5xl mx-auto p-6 md:p-12"
          >
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
                    <HardDrive className="w-6 h-6 text-emerald-500" />
                  </div>
                  <h1 className="text-3xl font-bold text-white tracking-tight">Dosya Merkezi</h1>
                </div>
                <p className="text-neutral-500">Hoş geldin, <span className="text-emerald-500 font-medium">yushA</span>. Dosyalarını yönetebilirsin.</p>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 active:scale-[0.98] disabled:opacity-50"
                >
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  Dosya Yükle
                </button>
                <button
                  onClick={handleLogout}
                  className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-5 py-2.5 rounded-xl transition-all flex items-center gap-2 active:scale-[0.98]"
                >
                  <LogOut className="w-4 h-4" />
                  Çıkış
                </button>
              </div>
            </header>

            <div className="grid grid-cols-1 gap-4">
              <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl overflow-hidden">
                <div className="grid grid-cols-12 px-6 py-4 border-bottom border-neutral-800 bg-neutral-900 text-xs font-bold text-neutral-500 uppercase tracking-wider">
                  <div className="col-span-6 md:col-span-7">Dosya Adı</div>
                  <div className="col-span-3 md:col-span-2">Boyut</div>
                  <div className="col-span-3 md:col-span-3 text-right">İşlem</div>
                </div>

                <div className="divide-y divide-neutral-800">
                  {files.length === 0 ? (
                    <div className="px-6 py-12 flex flex-col items-center justify-center text-neutral-600">
                      <File className="w-12 h-12 mb-4 opacity-20" />
                      <p>Henüz dosya yüklenmemiş.</p>
                    </div>
                  ) : (
                    files.map((file) => (
                      <motion.div
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        key={file.name}
                        className="grid grid-cols-12 px-6 py-4 items-center hover:bg-neutral-800/30 transition-colors group"
                      >
                        <div className="col-span-6 md:col-span-7 flex items-center gap-3">
                          <div className="w-10 h-10 bg-neutral-950 rounded-lg flex items-center justify-center border border-neutral-800 group-hover:border-emerald-500/30 transition-colors">
                            <File className="w-5 h-5 text-neutral-400 group-hover:text-emerald-500 transition-colors" />
                          </div>
                          <div className="truncate">
                            <p className="text-white font-medium truncate">{file.name.split('-').slice(1).join('-') || file.name}</p>
                            <p className="text-xs text-neutral-500">{new Date(file.createdAt).toLocaleDateString('tr-TR')}</p>
                          </div>
                        </div>
                        <div className="col-span-3 md:col-span-2 text-sm text-neutral-400">
                          {formatSize(file.size)}
                        </div>
                        <div className="col-span-3 md:col-span-3 text-right">
                          <button
                            onClick={() => handleDownload(file.name)}
                            className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all active:scale-90"
                            title="İndir"
                          >
                            <Download className="w-5 h-5" />
                          </button>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <footer className="mt-12 text-center text-neutral-600 text-xs">
              <p>&copy; 2026 yushA Upload. Tüm hakları saklıdır.</p>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
