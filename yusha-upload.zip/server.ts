import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import multer from 'multer';
import fs from 'fs';
import cors from 'cors';
import session from 'express-session';

declare module 'express-session' {
  interface SessionData {
    authenticated: boolean;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Ensure uploads directory exists
  const uploadDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
  }

  app.use(cors());
  app.use(express.json());
  app.use(session({
    secret: 'yusha-secret-key',
    resave: false,
    saveUninitialized: false,
    name: 'yusha-session',
    cookie: { 
      secure: true,
      sameSite: 'none',
      maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
  }));

  // Auth Middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.session.authenticated) {
      next();
    } else {
      res.status(401).json({ error: 'Unauthorized' });
    }
  };

  // Multer config
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-' + file.originalname);
    }
  });
  const upload = multer({ storage });

  // API Routes
  app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'yushA' && password === '1*sensinnn') {
      req.session.authenticated = true;
      res.json({ success: true });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  app.get('/api/auth-check', (req, res) => {
    res.json({ authenticated: !!req.session.authenticated });
  });

  app.get('/api/files', requireAuth, (req, res) => {
    fs.readdir(uploadDir, (err, files) => {
      if (err) return res.status(500).json({ error: 'Failed to read files' });
      
      const fileList = files.map(file => {
        const stats = fs.statSync(path.join(uploadDir, file));
        return {
          name: file,
          size: stats.size,
          createdAt: stats.birthtime
        };
      });
      res.json(fileList);
    });
  });

  app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    res.json({ success: true, file: req.file.filename });
  });

  app.get('/api/download/:filename', requireAuth, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename);
    if (fs.existsSync(filePath)) {
      res.download(filePath);
    } else {
      res.status(404).json({ error: 'File not found' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
